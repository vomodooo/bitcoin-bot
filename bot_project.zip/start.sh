#!/bin/bash
python bitcoin_bot.py
